class UserModel {
  int? id;
  String name;
  String email;
  String mobNo;

  UserModel({
    this.id,
    required this.name,
    required this.email,
    required this.mobNo,
  });
}
