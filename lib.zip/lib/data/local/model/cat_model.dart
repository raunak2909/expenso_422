class CatModel {
  int id;
  String title;
  String imgPath;

  CatModel({required this.id, required this.title, required this.imgPath});
}
